const BUTTON = document.querySelector('button')

BUTTON.addEventListener('click', () => {
  BUTTON.classList.toggle('bookmark-button--active')
})